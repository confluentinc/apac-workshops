import site
site.addsitedir('/home/dataiku/dataiku-dss-8.0.2/python.packages')
import pkg_resources
pkg_resources.fixup_namespace_packages('/home/dataiku/dataiku-dss-8.0.2/python.packages')
