-- setup Oracle DB
CONNECT sys/Oradoc_db1@localhost:1521/ORCLPDB1.localdomain as sysdba
-- create user
@/tmp/scripts/create_user.sql
CONNECT ordermgmt/kafka@localhost:1521/ORCLPDB1.localdomain
-- load data
@/tmp/scripts/cardholders_ddl.sql
@/tmp/scripts/merchants_ddl.sql
@/tmp/scripts/transactions_ddl.sql
@/tmp/scripts/transaction_generator.sql
-- setup cdc user
CONNECT sys/Oradoc_db1@localhost:1521/ORCLCDB.localdomain as sysdba
@/tmp/scripts/cdc_privs.sql
exit;