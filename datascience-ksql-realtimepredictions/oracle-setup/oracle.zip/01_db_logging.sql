-- please execute the following statements in a second terminal
docker exec -it oradb122 bash 
source /home/oracle/.bashrc
sqlplus sys/Oradoc_db1 as sysdba
sql> SHUTDOWN IMMEDIATE;
SQL> STARTUP MOUNT;
SQL> ALTER DATABASE ARCHIVELOG;
SQL> ALTER DATABASE OPEN;
-- Now, archive log is activated
SQL> ARCHIVE LOG LIST; 
-- Set logging all columns if a row is updated in CDB is optional
sql> ALTER SESSION SET CONTAINER=cdb$root;
sql> ALTER DATABASE ADD SUPPLEMENTAL LOG DATA (ALL) COLUMNS;
# Set logging all columns if a row is updated in PDB is a must
sql> ALTER SESSION SET CONTAINER=orclpdb1;
sql> ALTER DATABASE ADD SUPPLEMENTAL LOG DATA (ALL) COLUMNS; 
sql> exit;
exit;
-- When you are finished press enter in main script