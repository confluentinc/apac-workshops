-- TEST Data Generator
-- send every 5 sec a new generated transactions
-- an endless loop you can stop endless loop if you place
create table stop_generator (stop varchar2(1));
insert into stop_generator values ('N');
commit;
-- IF you send update stop_generator set stop='Y'; the procedure will stop


-- number
select dbms_random.string('a', 100) from dual;
-- nummber von bis
select DBMS_RANDOM.VALUE(1,100000000000) from dual;
-- integert 
select round(DBMS_RANDOM.VALUE(1,100)) from dual;



-- Transaction Generator
create or replace procedure TRANSACTION_GENERATOR as
l_transaction_id number;
l_merchant_id VARCHAR2(100); 
l_merchant_category_id NUMBER;
l_card_id VARCHAR2(100);
l_item_category varchar2(1);
l_purchase_amount number;
l_signature_provided number;
l_authorized_flag number;
l_stop VARCHAR2(1) := 'N';
begin
select max(id) into l_transaction_id from transactions; --328115
  FOR i in 1..100000 loop
     -- random merchants aufwählen
     select id, merchant_category_id into l_merchant_id, l_merchant_category_id from ( select id, merchant_category_id from merchants where id like '%' order by dbms_random.value) where rownum <= 1;
     -- card id 
     select id into l_card_id from ( select id from cardholders where id like '%' order by dbms_random.value) where rownum <= 1;
     -- item_category
     select dbms_random.string('U', 1) into l_item_category from dual;
     -- purchase_amount
     select DBMS_RANDOM.VALUE(1,100000) into l_purchase_amount from dual;
     -- signature_provided
     select round(DBMS_RANDOM.VALUE(0,1)) into l_signature_provided from dual;
     -- authorized_flag
     SELECT
       CASE
       WHEN DBMS_RANDOM.VALUE (0, 1) < 0.51 THEN NULL
       ELSE ROUND(DBMS_RANDOM.VALUE (0, 1))
       END
       into l_authorized_flag FROM dual;
     INSERT INTO transactions values (l_transaction_id+i,
                                      l_authorized_flag,
                                      to_char(sysdate, 'YYYY-MM-DD HH24:MI:SS'),
                                      l_card_id,
                                      l_merchant_id,
                                      l_merchant_category_id,
                                      l_item_category,
                                      l_purchase_amount,
                                      l_signature_provided);
     commit;
     select stop into l_stop from stop_generator;
     if l_stop = 'Y' THEN
       exit;
     end if;
     sys.dbms_lock.sleep(5);
  END LOOP;
end;
/