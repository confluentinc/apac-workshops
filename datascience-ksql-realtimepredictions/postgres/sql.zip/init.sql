CREATE TABLE public.transactions (
	id int8 NOT NULL PRIMARY KEY,
	authorized_flag int8 NULL,
	purchase_date text NULL,
	card_id text NULL,
	merchant_id text NULL,
	merchant_category_id int8 NULL,
	item_category text NULL,
	purchase_amount float8 NULL,
	signature_provided int8 NULL
);

CREATE TABLE public.merchants (
	id text NOT NULL PRIMARY KEY,
	merchant_category_id int8 NULL,
	subsector_description text NULL,
	latitude float8 NULL,
	longitude float8 NULL
);

CREATE TABLE public.cardholders (
	id text NOT NULL PRIMARY KEY,
	first_active_month text NULL,
	reward_program text NULL,
	latitude float8 NULL,
	longitude float8 NULL,
	fico_score int8 NULL,
	age int8 NULL
);
